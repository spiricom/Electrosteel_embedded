/*****************************************************************************
* File Name: main.c
*
* Version: 3.0
*
* Description:
*   The main C file for the Temperature measurement with Thermistor project. 
* 
* Note:
* 	The main project includes the ADC and other components required for the
*   temperature measurement. The Thermistor component is a complete firmware component
*   as decribed in the component datahseet and application note
******************************************************************************
* Copyright (C) 2015, Cypress Semiconductor Corporation.
******************************************************************************
* This software is owned by Cypress Semiconductor Corporation (Cypress) and is
* protected by and subject to worldwide patent protection (United States and
* foreign), United States copyright laws and international treaty provisions.
* Cypress hereby grants to licensee a personal, non-exclusive, non-transferable
* license to copy, use, modify, create derivative works of, and compile the
* Cypress Source Code and derivative works for the sole purpose of creating
* custom software in support of licensee product to be used only in conjunction
* with a Cypress integrated circuit as specified in the applicable agreement.
* Any reproduction, modification, translation, compilation, or representation of
* this software except as specified above is prohibited without the express
* written permission of Cypress.
*
* Disclaimer: CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH
* REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* Cypress reserves the right to make changes without further notice to the
* materials described herein. Cypress does not assume any liability arising out
* of the application or use of any product or circuit described herein. Cypress
* does not authorize its products for use as critical components in life-support
* systems where a malfunction or failure may reasonably be expected to result in
* significant injury to the user. The inclusion of Cypress' product in a life-
* support systems application implies that the manufacturer assumes all risk of
* such use and in doing so indemnifies Cypress against all charges. Use may be
* limited by and subject to the applicable Cypress software license agreement.
*****************************************************************************/
#include <device.h>
#include "removeOffsetNoise.h"
#include "measurement.h"
#include <stdio.h>

#define myBufferSize 16

uint8_t stringCapSensorsOnOff[1];
uint8_t stringCapSensorsRaw[16];

uint8 myArray[myBufferSize];
int32_t linearPotValue32Bit[4];
uint8_t i = 0;
uint8_t counter = 0;
uint8_t returnedData[myBufferSize];

void scanLinearResistor(uint8_t channel);

int main(void)
{
    
	char printBuf[16]={'\0'};


	CYGlobalIntEnable; 
	

	ADC_1_Start();
	AMux_1_Start();

	VDAC8_Start();
	Opamp_Start();
    
    SPIM_1_Start();
    SPIM_2_Start();

    CyDelay(500);
    CapSense_Start();        
    CapSense_InitializeAllBaselines() ;
    uint8_t myArrayCounter = 0;
    CapSense_ScanEnabledWidgets() ;    
    
	for(;;)
    {
        
        
        for (i = 0; i < 4; i++)
        {
            scanLinearResistor(i);
        }

        if(CapSense_IsBusy() == 0)        //if scan is complete   
        {             
            uint8_t byteCounter = 0;
            for (i = 0; i < 8; i++)
            {
                uint16 tempVar = CapSense_ReadSensorRaw(i);
                CapSense_CheckIsSensorActive(i);
                stringCapSensorsRaw[byteCounter++] = tempVar >> 8;
                
                stringCapSensorsRaw[byteCounter++] = tempVar & 0xff;
                
            }

            //LED_Write(0);
            CapSense_UpdateEnabledBaselines();
            CapSense_ScanEnabledWidgets();  
            if (CapSense_sensorOnMask[0] & (1<<4))
            {
              LED_Write(1);
            }
            else
            {
              LED_Write(0);
            }
            
        }    
        

           

        counter = 0;
        for (i = 0; i < 4; i++)
        {
            myArray[counter++] = ((uint16_t) linearPotValue32Bit[i]) >> 8;
            myArray[counter++] = linearPotValue32Bit[i] & 0xff;
        }
        myArray[8] = CapSense_sensorOnMask[0];
        
        
        //send and receive data over SPI from Genera 1

        
        for (int i = 0; i < myBufferSize; i++)
        {         

            SPIM_1_WriteTxData(myArray[i]);
            if ((SPIM_1_RX_STATUS_REG & SPIM_1_STS_RX_FIFO_NOT_EMPTY))
            {
                returnedData[i] = CY_GET_REG8(SPIM_1_RXDATA_PTR);
            }
        }
        //fill end of array with data from Genera 1 to send to Genera 2 (this data is shifted over by one, since we don't want to wait for the new data flag to get set)
        for (int i = 0; i < 7; i++)
        {
            myArray[i + 9] = returnedData[i+1];
        }
        
        //send and receive data over SPI from Genera 2
        for (int i = 0; i < myBufferSize; i++)
        {    

            SPIM_2_WriteTxData(myArray[i]);
            if ((SPIM_2_RX_STATUS_REG & SPIM_2_STS_RX_FIFO_NOT_EMPTY))
            {
                returnedData[i] = CY_GET_REG8(SPIM_2_RXDATA_PTR);
            }
        }
        //fill end of array with data from Genera 2 to send to Genera 1 (this data is shifted over by one, since we don't want to wait for the new data flag to get set)
        for (int i = 0; i < 7; i++)
        {
            myArray[i + 9] = returnedData[i+1];
        }
        
        
        
        
        
        /*
        if ((EZI2C_GetActivity() & EZI2C_STATUS_BUSY) == 0)
        {
           for (uint8_t i = 0; i < 16; i++)
            {
                myArray[i] = stringCapSensorsRaw[i];
            }
            myArray[16] = CapSense_sensorOnMask[0];
            
            counter = 17;
            for (i = 0; i < 4; i++)
            {
                myArray[counter++] = ((uint16_t) linearPotValue32Bit[i]) >> 8;
                myArray[counter++] = linearPotValue32Bit[i] & 0xff;
            }
        }
        */
        
     }
}

void scanLinearResistor(uint8_t channel)
{
        int32 iVtherm = 0;
        int32 iVref = 0;
        int32 iRes = 0;
        int32 offset = 0;
    
        AMux_1_FastSelect(channel * 2);
        ADC_1_StartConvert();
        ADC_1_IsEndConversion(ADC_1_WAIT_FOR_RESULT);
        iVtherm = ADC_1_GetResult32();
        
        	/* Get the offset voltage*/
	    AMux_1_FastSelect(8);
        ADC_1_StartConvert();
        ADC_1_IsEndConversion(ADC_1_WAIT_FOR_RESULT);
        offset = ADC_1_GetResult32();
        
        iVtherm =  iVtherm - offset;
	
        AMux_1_FastSelect((channel * 2) + 1);
        ADC_1_StartConvert();
        ADC_1_IsEndConversion(ADC_1_WAIT_FOR_RESULT);
        iVref = ADC_1_GetResult32();
        
        iVref =  iVref - offset;
        
        if ((iVref < 100) && (iVtherm > 10000))
        {
            iRes = 65535;
        }
        else
        {
            iRes = (int32)(((float)iVtherm / iVref) * REFERENCE_RESISTOR);
        }
        
        linearPotValue32Bit[channel] = iRes;
}


/* [] END OF FILE */
