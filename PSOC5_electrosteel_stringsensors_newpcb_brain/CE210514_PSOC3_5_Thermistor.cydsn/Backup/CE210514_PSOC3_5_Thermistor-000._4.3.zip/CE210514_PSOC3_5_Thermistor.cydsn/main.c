/*****************************************************************************
* File Name: main.c
*
* Version: 3.0
*
* Description:
*   
* 
* Note:
* 	The main project includes the ADC and other components required for the
*   temperature measurement. The Thermistor component is a complete firmware component
*   as decribed in the component datahseet and application note
******************************************************************************
* Copyright (C) 2015, Cypress Semiconductor Corporation.
******************************************************************************
* This software is owned by Cypress Semiconductor Corporation (Cypress) and is
* protected by and subject to worldwide patent protection (United States and
* foreign), United States copyright laws and international treaty provisions.
* Cypress hereby grants to licensee a personal, non-exclusive, non-transferable
* license to copy, use, modify, create derivative works of, and compile the
* Cypress Source Code and derivative works for the sole purpose of creating
* custom software in support of licensee product to be used only in conjunction
* with a Cypress integrated circuit as specified in the applicable agreement.
* Any reproduction, modification, translation, compilation, or representation of
* this software except as specified above is prohibited without the express
* written permission of Cypress.
*
* Disclaimer: CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH
* REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* Cypress reserves the right to make changes without further notice to the
* materials described herein. Cypress does not assume any liability arising out
* of the application or use of any product or circuit described herein. Cypress
* does not authorize its products for use as critical components in life-support
* systems where a malfunction or failure may reasonably be expected to result in
* significant injury to the user. The inclusion of Cypress' product in a life-
* support systems application implies that the manufacturer assumes all risk of
* such use and in doing so indemnifies Cypress against all charges. Use may be
* limited by and subject to the applicable Cypress software license agreement.
*****************************************************************************/
#include <device.h>
#include <stdio.h>

#define myBufferSize 1


volatile uint8 usbActivityCounter = 0u;
uint8 midiMsg[4];
uint8_t currentVBUS = 0;
uint8_t prevVBUS = 0;
volatile uint8_t USB_active = 0;
volatile uint8_t USB_check_flag = 0;

uint8 myArray[myBufferSize];
uint8 myInputArray[2];
int32_t linearPotValue32Bit[4];
uint8_t i = 0;
uint8_t counter = 0;
uint8_t returnedData[myBufferSize];
int32_t temper;
int previousButtons[11];
int octave = 0;
uint16_t angle[9];
uint16_t prevAngle[9];

uint16_t ADC_values[4];
uint16_t rawAngle = 0;


void checkUSB_Vbus(void);
void sendMIDIAllNotesOff(void);
void sendMIDIPitchBend(int val);
void firstCheckUSB_Vbus(void);
void restartSystemCheck(void);
void sendMIDINoteOn(int MIDInoteNum, int velocity);
void sendMIDIControlChange(int CCnum, int CCval);
CY_ISR_PROTO(SleepIsr_function);
void noteEvent(int string);
void I2C_reset(void);
void CCEvent(int bar);
void DmaRxConfiguration(void);
/* DMA Configuration for DMA_RX */
#define DMA_RX_BYTES_PER_BURST      (1u)
#define DMA_RX_REQUEST_PER_BURST    (1u)
#define DMA_RX_SRC_BASE             (CYDEV_PERIPH_BASE)
#define DMA_RX_DST_BASE             (CYDEV_SRAM_BASE)

#define PLUCK_BUFFER_SIZE                 (22u)
#define BAR_BUFFER_SIZE                 (8u)
#define STORE_TD_CFG_ONCMPLT        (1u)
uint8 rx1Channel, rx2Channel __attribute__((aligned(32)));;
uint8 rx1TD[2], rx2TD[2] __attribute__((aligned(32)));;

volatile uint8 rxBufferPluck[2][PLUCK_BUFFER_SIZE] __attribute__((aligned(32)));
volatile uint8 rxBufferBar[2][BAR_BUFFER_SIZE] __attribute__((aligned(32)));

uint16_t strings[10];
uint16_t prevStrings[10];
uint16_t bar[2];
uint16_t prevBar[2];
uint16_t maxStrings[10];
volatile uint8_t amHere = 0;
volatile uint8_t spiCounter = 0;
volatile uint8_t newDataFlag = 0;

volatile uint8_t amHere2 = 0;
volatile uint8_t spiCounter2 = 0;
volatile uint8_t newDataFlag2 = 0;
volatile uint8_t currentPluckBuffer = 0;
volatile uint8_t currentBarBuffer = 0;

CY_ISR(spis_1_function) {     /* No need to clear any interrupt source; interrupt component should be      * configured for RISING_EDGE mode.      */     /* Read the debouncer status reg just to clear it, no need to check its      * contents in this application.      */  
    //SPI receive from pluck detector
    uint8_t currentTd = 0;
    uint8_t state = 0;
     CyDmaChStatus(rx2Channel, &currentTd, &state);
    

    currentPluckBuffer = (currentTd & 1);
    if ((rxBufferPluck[currentPluckBuffer][0] == 254) && (rxBufferPluck[currentPluckBuffer][21] == 253))
    {
        for (int i = 0; i < 10; i++)
        {
            strings[i] = ((rxBufferPluck[currentPluckBuffer][i*2+1] << 7) + rxBufferPluck[currentPluckBuffer][i*2+2]);
        }
    }
    amHere = 1;
}

CY_ISR(spis_2_function) {     /* No need to clear any interrupt source; interrupt component should be      * configured for RISING_EDGE mode.      */     /* Read the debouncer status reg just to clear it, no need to check its      * contents in this application.      */  
    //SPI receive from pluck detector
    uint8_t currentTd = 0;
    uint8_t state = 0;
    CyDmaChStatus(rx1Channel, &currentTd, &state);
    currentBarBuffer = (currentTd & 1);
    if ((rxBufferBar[currentBarBuffer][6] == 254) && (rxBufferBar[currentBarBuffer][7] == 253))
    {
        for (int i = 0; i < 2; i++)
        {
            bar[i] = ((rxBufferBar[currentBarBuffer][i*2] << 8) + rxBufferBar[currentBarBuffer][i*2+1]);

        }
    }
    else
    {
        amHere2 = 1;
    }
    amHere = 1;
}



CY_ISR(SleepIsr_function)
{
    if (USB_active)
    {
        //check USB activity
        if( USB_CheckActivity() != 0u ) 
        {
            usbActivityCounter = 0u;
        } 
        else 
        {
            usbActivityCounter++;
        }

    }
    //Clear pending interrupt
    SleepTimer_GetStatus();
}

    static uint8 CYCODE eepromArray[]={ 0, 0 };
                                            
    uint8 array[] ={ 0, 0 };
                                
    /*Return status for EEPROM and UART*/ 
cy_en_em_eeprom_status_t eepromReturnValue;


/* EEPROM storage in work flash, this is defined in Em_EEPROM.c*/
#if defined (__ICCARM__)
#pragma data_alignment = CY_FLASH_SIZEOF_ROW
const uint8_t Em_EEPROM_em_EepromStorage[Em_EEPROM_PHYSICAL_SIZE] = {0u};
#else
const uint8_t Em_EEPROM_em_EepromStorage[Em_EEPROM_PHYSICAL_SIZE]
__ALIGNED(CY_FLASH_SIZEOF_ROW) = {0u};
#endif /* defined (__ICCARM__) */

    uint8 eeprom_cnt;
    cystatus status;
    volatile const uint8 * ptr;
volatile int barCount = 0;

#define I2C_1_TIMEOUT_ENABLE 1u //overwrites the default in the i2c block
    
//this ISR should happen when a USB cable is plugged in or unplugged.

CY_ISR(Vbus_function)
{
    //plug or unplug event
    //check if eeprom has a flag saying you just restarted. If so, don't restart again
    //otherwise, restart
    my_Vbus_ISR_ClearPending();
    vBusPin_ClearInterrupt();
    restartSystemCheck();

}

void restartSystemCheck()
{
    eepromReturnValue = Em_EEPROM_Read(0u, eepromArray, 2u);
    if (*(volatile uint8 *) &eepromArray[0] == 1u)
    {
        //a flag says we just restarted
        //write a zero so it knows next time that it's OK to restart
        array[0] = 0;
        Em_EEPROM_Write(0u,array,2u);     
        USB_check_flag = 1;
    }
    else
    {
       //otherwise, we need to restart
       array[0] = 1;
       Em_EEPROM_Write(0u,array,2u);  
        USB_Stop();
        I2C_1_Stop();
       CySoftwareReset();
    }
}
    
uint8 I2C_MasterWriteBlocking(uint8 i2CAddr, uint8 nbytes, uint8_t mode);
uint8 I2C_MasterReadBlocking(uint8 i2CAddr, uint8 nbytes, uint8_t mode);
void USB_service(void);

volatile uint8_t I2Cbuff1[16];
volatile uint8_t I2Cbuff2[16];
uint8_t I2Cbuff3[16];

volatile uint8_t send_it = 0;

uint8_t mux_states[9][2] = {{0,0}, {0,1}, {0,2}, {0,3}, {0,4}, {2, 2}, {3, 3}, {4, 4}, {5, 5}};
uint8_t last_mux = 1;
volatile uint8_t main_counter = 0;

int main(void)
{

	CYGlobalIntEnable; 
   // DmaRxConfiguration();
    //isr_1_StartEx(isr_1_function);
    //isr_SPI1_DMA_StartEx(spis_1_function);
    //isr_SPI2_DMA_StartEx(spis_2_function);
    //SPIS_1_Start();  
    //SPIS_2_Start(); 

    //CyDmaChEnable(rxChannel, STORE_TD_CFG_ONCMPLT);
    


    //SPIM_1_Start();
 


    CyDelay(150);
    eepromReturnValue = Em_EEPROM_Init((uint32_t)Em_EEPROM_em_EepromStorage);
    if(eepromReturnValue != CY_EM_EEPROM_SUCCESS)
    {
       // HandleError();
    }
    uint8_t myArrayCounter = 0;
    I2C_1_Start();    
    //USB_SetPowerStatus(USB_DEVICE_STATUS_SELF_POWERED);
    //my_Vbus_ISR_StartEx(Vbus_function);
    ADC_SAR_Seq_1_Start();
    ADC_SAR_Seq_1_StartConvert();
    //if (!USB_VBusPresent())
    {
       // restartSystemCheck();
    }


    CyDelay(1);
    
    uint8_t myCount  = 0;
	for(;;)
    {
        //if (newDataFlag)
        //{
        //}
            /*
            for (int i = 0; i < 5; i++)
            {
                I2C_1_MasterSendStart(0x70, 0); 
                I2C_1_MasterWriteByte(1<<i);
                I2C_1_MasterSendStop(); 


                I2C_1_MasterSendStart(0x36, 0); 
                I2C_1_MasterWriteByte(0x0C);
                //I2C_1_MasterSendStop();
                I2C_1_MasterSendRestart(0x36, 1); 
                rawAngle = I2C_1_MasterReadByte(1) << 8;
                //I2C_1_MasterSendRestart(0x36, 1);
                rawAngle +=  I2C_1_MasterReadByte(0);
                 I2C_1_MasterSendStop(); 
                
                CyDelay(1);

                I2C_1_MasterSendStart(0x36, 0); 
                I2C_1_MasterWriteByte(0x01);
                I2C_1_MasterWriteByte(rawAngle >> 8);
                I2C_1_MasterWriteByte(rawAngle & 0xff);
                I2C_1_MasterWriteByte((rawAngle+500) >> 8);
                I2C_1_MasterWriteByte((rawAngle+500) & 0xff);
                I2C_1_MasterSendStop(); 
                
                CyDelay(2);

                I2C_1_MasterSendStart(0x36, 0); 
                I2C_1_MasterWriteByte(0xff);
               I2C_1_MasterWriteByte(0x80);
                I2C_1_MasterSendStop(); 
               CyDelay(2);
            }
        */
        //set main i2c mux
    
        
        /*
        for (int i = 0; i < 4; i++)
        {
            I2C_1_MasterSendStart(0x71, 0); 
            I2C_1_MasterWriteByte(1<<(i+2));
            I2C_1_MasterSendStop(); 


            I2C_1_MasterSendStart(0x36, 0); 
            I2C_1_MasterWriteByte(0x0C);
            //I2C_1_MasterSendStop();
            I2C_1_MasterSendRestart(0x36, 1); 
            rawAngle = I2C_1_MasterReadByte(1) << 8;
            //I2C_1_MasterSendRestart(0x36, 1);
            rawAngle +=  I2C_1_MasterReadByte(0);
             I2C_1_MasterSendStop(); 
            
            CyDelay(1);

            I2C_1_MasterSendStart(0x36, 0); 
            I2C_1_MasterWriteByte(0x01);
            I2C_1_MasterWriteByte(rawAngle >> 8);
            I2C_1_MasterWriteByte(rawAngle & 0xff);
            I2C_1_MasterWriteByte((rawAngle+700) >> 8);
            I2C_1_MasterWriteByte((rawAngle+700) & 0xff);
            I2C_1_MasterSendStop(); 
            
            CyDelay(2);

            I2C_1_MasterSendStart(0x36, 0); 
            I2C_1_MasterWriteByte(0xff);
            I2C_1_MasterWriteByte(0x80);
            I2C_1_MasterSendStop(); 
           CyDelay(2);
        }
            */
            
        
        if (mux_states[main_counter][0] != last_mux)
        {
            I2Cbuff1[0] = 1<<mux_states[main_counter][0];
            uint8_t status = I2C_MasterWriteBlocking(0x71, 1, I2C_1_MODE_COMPLETE_XFER);
        }
        last_mux = mux_states[main_counter][0];
        
        CyDelayUs(10);
        if (mux_states[main_counter][0] == 0)
        {
            I2Cbuff1[0] = 1<<mux_states[main_counter][1];
            status = I2C_MasterWriteBlocking(0x70, 1, I2C_1_MODE_COMPLETE_XFER);
        }
        CyDelayUs(10);
        I2Cbuff1[0] = 0x0E;
        status = I2C_MasterWriteBlocking(0x36, 1, I2C_1_MODE_NO_STOP);
        status = I2C_MasterReadBlocking(0x36, 2, I2C_1_MODE_REPEAT_START);
        CyDelayUs(10);
        angle[main_counter] = I2Cbuff2[0] << 8;
        angle[main_counter] +=  I2Cbuff2[1];
        
        
        
        /*
        I2Cbuff1[0] = 1<<main_counter;
        uint8_t status = I2C_MasterWriteBlocking(0x71, 1, I2C_1_MODE_COMPLETE_XFER);

                for (int i = 0; i < 5; i++)
                {
                    I2Cbuff1[0] = 1<<i;
                    status = I2C_MasterWriteBlocking(0x70, 1, I2C_1_MODE_COMPLETE_XFER);

                    I2Cbuff1[0] = 0x0E;
                    status = I2C_MasterWriteBlocking(0x36, 1, I2C_1_MODE_NO_STOP);

                    status = I2C_MasterReadBlocking(0x36, 2, I2C_1_MODE_REPEAT_START);


                    angle[i] = I2Cbuff2[0] << 8;
                    angle[i] +=  I2Cbuff2[1];
                }
            if (main_counter == 0)
            {               
                I2Cbuff1[0] = 1<<main_counter;
                uint8_t status = I2C_MasterWriteBlocking(0x71, 1, I2C_1_MODE_COMPLETE_XFER);

                for (int i = 0; i < 5; i++)
                {
                    I2Cbuff1[0] = 1<<i;
                    status = I2C_MasterWriteBlocking(0x70, 1, I2C_1_MODE_COMPLETE_XFER);

                    I2Cbuff1[0] = 0x0E;
                    status = I2C_MasterWriteBlocking(0x36, 1, I2C_1_MODE_NO_STOP);

                    status = I2C_MasterReadBlocking(0x36, 2, I2C_1_MODE_REPEAT_START);


                    angle[i] = I2Cbuff2[0] << 8;
                    angle[i] +=  I2Cbuff2[1];
                }
            }
            else
            {
                I2Cbuff1[0] = 1<<(main_counter+1);
                uint8_t status = I2C_MasterWriteBlocking(0x71, 1, I2C_1_MODE_COMPLETE_XFER);
                I2Cbuff1[0] = 0x0E;
                status = I2C_MasterWriteBlocking(0x36, 1, I2C_1_MODE_NO_STOP);
                if (status == I2C_1_MSTAT_ERR_XFER)
                {
                    I2Cbuff1[0] = 1<<(main_counter+1);
                    status = I2C_MasterWriteBlocking(0x71, 1, I2C_1_MODE_COMPLETE_XFER);
                }
           


                status = I2C_MasterReadBlocking(0x36, 2, I2C_1_MODE_REPEAT_START);
                 //I2C_1_MasterReadBuf(0x36, I2Cbuff3, 2, I2C_1_MODE_REPEAT_START);
                if (status == I2C_1_MSTAT_ERR_XFER)
                {
                    I2Cbuff1[0] = 1<<(main_counter+1);
                    status = I2C_MasterWriteBlocking(0x71, 1, I2C_1_MODE_COMPLETE_XFER);
                }
                
                angle[main_counter+4] = I2Cbuff2[0] << 8;
                angle[main_counter+4] +=  I2Cbuff2[1];
            }    
                

            send_it = 1;
        }
        */
        

        if (angle[main_counter] != prevAngle[main_counter])
        {
            sendMIDIControlChange(main_counter, (angle[main_counter] >> 7));
            sendMIDIControlChange(main_counter+36, (angle[main_counter] & 127));
        }
        prevAngle[main_counter] = angle[main_counter];
        main_counter++;
        if (main_counter >= 9)
        {
            main_counter = 0;
        }
        
        barCount++;
        if (barCount > 4)
        {
            for (int i = 0; i < 2; i++)
            {
                if (bar[i] != prevBar[i])
                {
                    CCEvent(i);
                }
                prevBar[i] = bar[i];
            }
            barCount = 0;
        }
        for (int i = 0 ; i < 10; i++)
        {
            if (strings[i] != prevStrings[i])
            {
                noteEvent(i);
            }
            prevStrings[i] = strings[i];
        }
       // if (USB_check_flag)
        {
            //checkUSB_Vbus();
        }
        //only service the USB bus if there is a computer plugged in
       // if ((USB_active) && (USB_VBusPresent()))
        {
           // USB_service();
        }

        


            //myArray[16] = CapSense_sensorOnMask[0];
            
            //counter = 17;

        
     



    /*
         for (int i = 0; i < myBufferSize; i++)
        {         

            SPIM_1_WriteTxData(myArray[i]);
            //
            //if ((SPIM_1_RX_STATUS_REG & SPIM_1_STS_RX_FIFO_NOT_EMPTY))
            //{
            //    returnedData[i] = CY_GET_REG8(SPIM_1_RXDATA_PTR);
            //}
            //
        }
        */
        /*
        //fill end of array with data from Genera 1 to send to Genera 2 
        for (int i = 0; i < 7; i++)
        {
            myArray[i + 9] = returnedData[i];
        }
        */
        //send and receive data over SPI from Genera 2
        //for (int i = 0; i < myBufferSize; i++)
        //{    

            //SPIS_1_WriteTxData(myArray[i]);
            //if ((SPIM_2_RX_STATUS_REG & SPIM_2_STS_RX_FIFO_NOT_EMPTY))
            //{
           //     returnedData[i] = CY_GET_REG8(SPIM_2_RXDATA_PTR);
           // }
        //}
        /*
        //fill end of array with data from Genera 2 to send to Genera 1 
        for (int i = 0; i < 7; i++)
        {
            myArray[i + 9] = returnedData[i];
        }
        */
        
        /*
        if ((EZI2C_GetActivity() & EZI2C_STATUS_BUSY) == 0)
        {
           for (uint8_t i = 0; i < 16; i++)
            {
                myArray[i] = stringCapSensorsRaw[i];
            }
            myArray[16] = CapSense_sensorOnMask[0];
            
            counter = 17;
            for (i = 0; i < 4; i++)
            {
                myArray[counter++] = ((uint16_t) linearPotValue32Bit[i]) >> 8;
                myArray[counter++] = linearPotValue32Bit[i] & 0xff;
            }
        }
        */
        
     }
}



void DmaRxConfiguration()
{ 
    rx1Channel = DMA_2_DmaInitialize(DMA_RX_BYTES_PER_BURST, DMA_RX_REQUEST_PER_BURST,
                                     HI16(DMA_RX_SRC_BASE), HI16(DMA_RX_DST_BASE));

    rx1TD[0] = CyDmaTdAllocate();
    rx1TD[1] = CyDmaTdAllocate();

    CyDmaTdSetConfiguration(rx1TD[0], BAR_BUFFER_SIZE, rx1TD[1] , TD_INC_DST_ADR | DMA_2__TD_TERMOUT_EN);
    CyDmaTdSetConfiguration(rx1TD[1], BAR_BUFFER_SIZE, rx1TD[0] , TD_INC_DST_ADR | DMA_2__TD_TERMOUT_EN);
    CyDmaTdSetAddress(rx1TD[0], LO16((uint32) SPIS_2_RXDATA_PTR), LO16((uint32) rxBufferBar[0]));
    CyDmaTdSetAddress(rx1TD[1], LO16((uint32) SPIS_2_RXDATA_PTR), LO16((uint32) rxBufferBar[1]));
    CyDmaChSetInitialTd(rx1Channel, rx1TD[0]);
    CyDmaChEnable(rx1Channel, 1);
    
    
    rx2Channel = DMA_1_DmaInitialize(DMA_RX_BYTES_PER_BURST, DMA_RX_REQUEST_PER_BURST,
                                     HI16(DMA_RX_SRC_BASE), HI16(DMA_RX_DST_BASE));

    rx2TD[0] = CyDmaTdAllocate();
    rx2TD[1] = CyDmaTdAllocate();

    CyDmaTdSetConfiguration(rx2TD[0], PLUCK_BUFFER_SIZE, rx2TD[1] , TD_INC_DST_ADR | DMA_1__TD_TERMOUT_EN);
    CyDmaTdSetConfiguration(rx2TD[1], PLUCK_BUFFER_SIZE, rx2TD[0] , TD_INC_DST_ADR | DMA_1__TD_TERMOUT_EN);
    CyDmaTdSetAddress(rx2TD[0], LO16((uint32) SPIS_1_RXDATA_PTR), LO16((uint32) rxBufferPluck[0]));
    CyDmaTdSetAddress(rx2TD[1], LO16((uint32) SPIS_1_RXDATA_PTR), LO16((uint32) rxBufferPluck[1]));
    CyDmaChSetInitialTd(rx2Channel, rx2TD[0]);
    CyDmaChEnable(rx2Channel, 1);
}

uint8 I2C_MasterWriteBlocking(uint8 i2CAddr, uint8 nbytes, uint8_t mode)
{
    uint8 volatile status;
    uint32_t timeout = 50000;
    status = I2C_1_MasterClearStatus();
    if(!(status & I2C_1_MSTAT_ERR_XFER))
    {
        status = I2C_1_MasterWriteBuf(i2CAddr, (uint8 *)&I2Cbuff1, nbytes,
                                     mode);
        if(status == I2C_1_MSTR_NO_ERROR)
        {
            /* wait for write complete and no error */
            do
            {
                status = I2C_1_MasterStatus();
                timeout--;
                if (status == I2C_1_MSTAT_ERR_XFER)
                {
                    I2C_reset();
                }
                if (timeout == 0)
                {
                    status = I2C_1_MSTAT_ERR_XFER;
                    I2C_reset();
                }
                if (status == 0)
                {
                    status = I2C_1_MSTAT_ERR_XFER;
                    I2C_reset();
                }
                
            } while(((status & (I2C_1_MSTAT_WR_CMPLT | I2C_1_MSTAT_ERR_XFER)) == 0u) && (status != 0u) && (timeout>0));
        }
        else
        {
            /* translate from I2CM_MasterWriteBuf() error output to
            *  I2CM_MasterStatus() error output */
            status = I2C_1_MSTAT_ERR_XFER;
            I2C_reset();
        }
    }
    
    return status;
}

uint8 I2C_MasterReadBlocking(uint8 i2CAddr, uint8 nbytes, uint8_t mode)
{
    uint8 volatile status;
    uint32_t timeout = 50000;
    status = I2C_1_MasterClearStatus();
    if(!(status & I2C_1_MSTAT_ERR_XFER))
    {
        status = I2C_1_MasterReadBuf(i2CAddr,
                                   (uint8 *)&(I2Cbuff2),
                                    nbytes, mode); 
        if(status == I2C_1_MSTR_NO_ERROR)
        {
            /* wait for read complete and no error */
            do
            {
                status = I2C_1_MasterStatus();
                timeout--;
                if (status == I2C_1_MSTAT_ERR_XFER)
                {
                    I2C_1_GENERATE_STOP_MANUAL;
                    I2C_reset();
                }
                if (timeout == 0)
                {
                    status = I2C_1_MSTAT_ERR_XFER;
                    I2C_reset();
                }
                if (status == 0)
                {
                    status = I2C_1_MSTAT_ERR_XFER;
                    I2C_reset();
                }
            } while(((status & (I2C_1_MSTAT_RD_CMPLT | I2C_1_MSTAT_ERR_XFER)) == 0u) && (status != 0u) && (timeout>0));
        }
        else
        {
            /* translate from I2CM_MasterReadBuf() error output to
            *  I2CM_MasterStatus() error output */
            status = I2C_1_MSTAT_ERR_XFER;
            I2C_reset();
        }
    }
    return status;
}

void I2C_reset(void)
{
    //I2C_1_GENERATE_STOP_MANUAL;
    //I2C_1_state = I2C_1_SM_EXIT_IDLE;
    //CyDelay(100);
    ///I2C_1_Stop();
    //CyDelay(100);
    //I2C_1_Init();
    //CyDelay(100);
    //I2C_1_Start();
    CyDelay(100);
            if (mux_states[main_counter][0] != last_mux)
        {
            I2Cbuff1[0] = 1<<mux_states[main_counter][0];
            uint8_t status = I2C_MasterWriteBlocking(0x71, 1, I2C_1_MODE_COMPLETE_XFER);
        }
        last_mux = mux_states[main_counter][0];
        
        CyDelayUs(10);
        if (mux_states[main_counter][0] == 0)
        {
            I2Cbuff1[0] = 1<<mux_states[main_counter][1];
            status = I2C_MasterWriteBlocking(0x70, 1, I2C_1_MODE_COMPLETE_XFER);
        }
        main_counter = 0;
}

void checkUSB_Vbus(void)
{
   if (USB_VBusPresent() == 0)
   {
       USB_Stop();
       //LED_PWM_Write(0);
       USB_active = 0; 
        //CySoftwareReset();
   }
   else if (USB_active == 0 )
   {
       USB_Start(0u, USB_3V_OPERATION ); 
        while (0u == USB_GetConfiguration());
        USB_MIDI_EP_Init();
       //LED_PWM_Write(255);
       USB_active = 1;
   }
   USB_check_flag = 0;
}



void USB_service(void)
{
    if(USB_IsConfigurationChanged() != 0u)
    {
        if(USB_GetConfiguration() != 0u)   
        {
           // Sleep_isr_StartEx(SleepIsr_function);
            
            //SleepTimer_Start();
        	
            if ((USB_active) && (USB_VBusPresent()))
            {
                USB_MIDI_EP_Init();
            }
        }
        else
        {
            //SleepTimer_Stop();
        }    
    }        
    
    if(USB_GetConfiguration() != 0u)    
    {
        
        #if(USB_EP_MM != USB__EP_DMAAUTO) 
            if ((USB_active) && (USB_VBusPresent()))
            {
                USB_MIDI_IN_Service();
            }
        #endif

        #if(USB_EP_MM != USB__EP_DMAAUTO) 
            if ((USB_active) && (USB_VBusPresent()))
            {
                USB_MIDI_OUT_Service();
            }
        #endif

/*
        if( usbActivityCounter >= 2u ) 
        {

            USB_Suspend();

            CyPmSaveClocks();
            CyPmSleep(PM_SLEEP_TIME_NONE, PM_SLEEP_SRC_PICU);
            CyPmRestoreClocks();

            USB_Resume();
            USB_MIDI_EP_Init();
            
            usbActivityCounter = 0u; 

        }
        */
    }
        
}


void noteEvent(int string)
{
    if (strings[string] > maxStrings[string])
    {
        maxStrings[string] = strings[string];
    }
    if (strings[string] == 0)
    {
         sendMIDINoteOn(string+60, 0);
    }
    else
    {
        sendMIDINoteOn(string+60, ((uint8_t)(((float)strings[string] / (float)maxStrings[string]) * 126.0f))+1 );
    }
}

void CCEvent(int cc)
{

    sendMIDIControlChange(64+(cc*3), ((uint8_t) ((bar[cc] >> 14) & 127)));
    sendMIDIControlChange(65+(cc*3), ((uint8_t) ((bar[cc] >> 7) & 127)));
    sendMIDIControlChange(66+(cc*3), ((uint8_t) ((bar[cc]) & 127)));
    
}

void sendMIDINoteOn(int MIDInoteNum, int velocity)
{  
   
    midiMsg[0] = USB_MIDI_NOTE_ON;
    midiMsg[1] = MIDInoteNum;
    midiMsg[2] = velocity;	
    //MIDI1_UART_PutArray(midiMsg, 3);
    if ((USB_active) && (USB_VBusPresent()))
    {
        USB_PutUsbMidiIn(3u, midiMsg, USB_MIDI_CABLE_00);
    } 
    
}

void sendMIDIPolyKeyPressure(int MIDInoteNum, int pressure)
{
    midiMsg[0] = USB_MIDI_POLY_KEY_PRESSURE;
    midiMsg[1] = MIDInoteNum;
    midiMsg[2] = pressure;		
    //MIDI1_UART_PutArray(midiMsg, 3);

    if ((USB_active) && (USB_VBusPresent()))
    {
        USB_PutUsbMidiIn(3u, midiMsg, USB_MIDI_CABLE_00);
    } 
}

void sendMIDIControlChange(int CCnum, int CCval)
{
    midiMsg[0] = USB_MIDI_CONTROL_CHANGE;
    midiMsg[1] = CCnum;
    midiMsg[2] = CCval;			
    //MIDI1_UART_PutArray(midiMsg, 3);
    
    if ((USB_active) && (USB_VBusPresent()))
    {
        USB_PutUsbMidiIn(3u, midiMsg, USB_MIDI_CABLE_00);
    } 
}

void sendMIDIPitchBend(int val)
{
    midiMsg[0] = USB_MIDI_PITCH_BEND_CHANGE;
    midiMsg[1] = (val & 127); //LSB
    midiMsg[2] = (val >> 7);	//MSB		

    //MIDI1_UART_PutArray(midiMsg, 3);
    
    if ((USB_active) && (USB_VBusPresent()))
    {
        USB_PutUsbMidiIn(3u, midiMsg, USB_MIDI_CABLE_00);
    } 
}

void sendMIDIAllNotesOff(void)
{   
    for (i = 0; i < 128; i++)
    {
        midiMsg[0] = USB_MIDI_NOTE_ON;
        midiMsg[1] = i;
        midiMsg[2] = 0;	
       // MIDI1_UART_PutArray(midiMsg, 3);
        if ((USB_active) && (USB_VBusPresent()))
        {       
            USB_PutUsbMidiIn(3u, midiMsg, USB_MIDI_CABLE_00);
        }
    }
}

// this gets called if the Brain gets a MIDI message from the computer host
void USB_callbackLocalMidiEvent(uint8 cable, uint8 *midiMsg) CYREENTRANT
{   
    
    //check that we got here
    
    if ((USB_active) && (USB_VBusPresent()))
    { 
        /*
        if(midiMsg[USB_EVENT_BYTE0] == USB_MIDI_NOTE_ON)
        {
    
            //write the note on into the masterKeys array, which stores all the pitches on/off info for the brain
            masterKeys[ midiMsg[USB_EVENT_BYTE1] ][0] = midiMsg[USB_EVENT_BYTE2];
            int possibleKey = (int)USB_EVENT_BYTE1 + (int)cvOffsetFinal - 32 - (int)keyOffset;
            if ((possibleKey < NUM_KEYS) && (possibleKey >= 0))
            {
                //looks like the MIDI note from the computer also lands on the keyboard with the current CV offset and keyOffset, so associate it with a key
                masterKeys[ midiMsg[USB_EVENT_BYTE1] ][1] = possibleKey;
            }
            else
            {
                masterKeys[ midiMsg[USB_EVENT_BYTE1] ][1] = -1;
            }
            if (midiMsg[USB_EVENT_BYTE2] > 0)
            {
                //note on
                addToNoteStack(midiMsg[USB_EVENT_BYTE1]);
                if (mainMode == SEQUENCERMODE)
                {
                    if (toggleKeys[midiMsg[USB_EVENT_BYTE1]] == 0)
                    {
                        toggleKeys[midiMsg[USB_EVENT_BYTE1]] = 1;
                        addToSequencerStack(midiMsg[USB_EVENT_BYTE1]);
                    }
                    else
                    {
                        toggleKeys[midiMsg[USB_EVENT_BYTE1]] = 0;
                        removeFromSequencerStack(midiMsg[USB_EVENT_BYTE1]);
                    }
                }
            }
            else
            {
                //note off
                removeFromNoteStack(midiMsg[USB_EVENT_BYTE1]);
            }
            
        }
        
        if (midiMsg[USB_EVENT_BYTE0] == USB_MIDI_CONTROL_CHANGE)
        {
            computerCC[midiMsg[USB_EVENT_BYTE2]] = midiMsg[USB_EVENT_BYTE1];
            
            if (midiMsg[USB_EVENT_BYTE2] == 0) // low res 7-bit full value
            {
                DACvalue16 = (midiMsg[USB_EVENT_BYTE1] << 5); 
                //send the DAC value to masterpitch sensor
                WriteCommandPacket((DACvalue16 >> 8),(DACvalue16 & 255) , masterPitch);
            }
            
            if (midiMsg[USB_EVENT_BYTE2] == 1) // high byte
            {
                DACvalue16 = (midiMsg[USB_EVENT_BYTE1] << 7) + DAClowbyte7; 
                //send the DAC value to masterpitch sensor
                WriteCommandPacket((DACvalue16 >> 8),(DACvalue16 & 255) , masterPitch);
            }
            if (midiMsg[USB_EVENT_BYTE2] == 2) // low byte
            {
                DAClowbyte7 = midiMsg[USB_EVENT_BYTE1];
            }

        }
        */
        cable = cable; // so it doesn't complain about unused variables
    }
}    

/* [] END OF FILE */
